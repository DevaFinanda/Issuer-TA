/**
 * Authorization Controller — OID4VCI Authorization Code Flow
 * 
 * Implements:
 *   GET  /authorize  — Redirect to frontend login page (wallet calls this)
 *   POST /authorize  — Authenticate user + generate authorization code
 *   POST /register   — Register new holder user
 */

import { Request, Response } from 'express'
import {
  authenticateAndGenerateCode,
  authenticateUserLogin,
  AuthError,
} from '../services/auth.service.js'
import { generateAccessToken } from '../services/token.service.js'
import { registerHolder } from '../services/user.service.js'
import {
  validateAuthorizeRequest,
  validateLoginRequest,
  validateRegistration,
} from '../security/validation.js'

export class AuthController {
  /**
   * GET /authorize  (and /oid4vci/authorize)
   *
   * Called by the wallet after reading the credential offer.
   * Redirects to the frontend /authorize page so the holder can log in
   * using the React UI instead of the inline HTML fallback.
   *
   * Query params are forwarded as-is: response_type, client_id, redirect_uri, state
   */
  static getAuthorize(req: Request, res: Response) {
    // Forward all query params to the frontend authorization page
    const params = new URLSearchParams()
    for (const [key, value] of Object.entries(req.query)) {
      if (value !== undefined && value !== null) {
        params.set(key, String(value))
      }
    }

    const frontendAuthorizeUrl = `/authorize${params.toString() ? `?${params.toString()}` : ''}`
    return res.redirect(302, frontendAuthorizeUrl)
  }

  /**
   * POST /login
   *
   * Body: { username, password }
   *
   * If valid, returns an access token and the next credential issuance step.
   */
  static async postLogin(req: Request, res: Response) {
    try {
      const validation = validateLoginRequest(req.body)
      if (!validation.valid) {
        return res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: validation.errors,
        })
      }

      const { username, password } = req.body

      const auth = await authenticateUserLogin({ username, password })
      const token = await generateAccessToken(auth.userId)

      return res.json({
        success: true,
        accessToken: token.accessToken,
        tokenType: 'Bearer',
        expiresIn: token.expiresIn,
        nextStep: {
          endpoint: '/request-credential',
          method: 'POST',
          payload: {
            holderDid: 'did:web:wallet.identia.my.id',
          },
        },
      })
    } catch (error: any) {
      if (error instanceof AuthError) {
        return res.status(error.statusCode).json({
          success: false,
          error: error.message,
        })
      }

      console.error('❌ Login error:', error.message)
      return res.status(500).json({
        success: false,
        error: 'Login failed',
      })
    }
  }

  /**
   * POST /authorize
   * 
   * Called by the frontend after the user submits NIK + password.
   * Authenticates the user and returns an authorization code via redirect URL.
   * 
   * Body: { nik, password, client_id, redirect_uri, state }
   */
  static async postAuthorize(req: Request, res: Response) {
    const contentType = (req.headers['content-type'] || '').toString()
    const isFormPost = contentType.includes('application/x-www-form-urlencoded')

    const renderErrorPage = (message: string, statusCode: number = 400) => {
      const escaped = String(message)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')

      return res.status(statusCode).send(`<!doctype html>
<html lang="id"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Otorisasi Gagal</title>
<style>body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif;background:#f8fafc;margin:0;padding:24px}.card{max-width:420px;margin:20px auto;background:#fff;border:1px solid #fecaca;border-radius:12px;padding:16px}.title{color:#991b1b;font-size:20px;margin:0 0 8px}.msg{color:#7f1d1d}.btn{display:inline-block;margin-top:14px;background:#2563eb;color:#fff;padding:10px 14px;border-radius:8px;text-decoration:none}</style>
</head><body><div class="card"><h1 class="title">Otorisasi Gagal</h1><p class="msg">${escaped}</p><a class="btn" href="javascript:history.back()">Kembali</a></div></body></html>`)
    }

    try {
      // Validate input
      const validation = validateAuthorizeRequest(req.body)
      if (!validation.valid) {
        if (isFormPost) {
          return renderErrorPage(validation.errors.join(', '), 400)
        }
        return res.status(400).json({
          error: 'invalid_request',
          error_description: validation.errors.join(', '),
        })
      }

      const { password, client_id, redirect_uri, state } = req.body
      const identifier = (req.body.identifier || req.body.nik || '').toString().trim()

      // Authenticate and generate authorization code
      const result = await authenticateAndGenerateCode({
        identifier,
        password,
        clientId: client_id,
        redirectUri: redirect_uri,
        state,
      })

      console.log('✅ Authorization code issued, redirect URL:', result.redirectUrl)

      // Only do a browser redirect for real HTML form submissions.
      // JSON API calls (e.g. from the React frontend via Axios/fetch) must receive
      // a JSON body — not a 302 — because custom-scheme URIs (identia-wallet://)
      // cannot be followed by fetch/Axios and would cause a network error.
      if (isFormPost) {
        return res.redirect(result.redirectUrl)
      }

      res.json({
        success: true,
        code: result.code,
        redirect_uri: redirect_uri,
      })
    } catch (error: any) {
      if (error instanceof AuthError) {
        if (isFormPost) {
          return renderErrorPage(error.message, error.statusCode)
        }

        return res.status(error.statusCode).json({
          error: 'access_denied',
          error_description: error.message,
        })
      }

      console.error('❌ Authorization error:', error.message)

      if (isFormPost) {
        return renderErrorPage('Internal server error', 500)
      }

      res.status(500).json({
        error: 'server_error',
        error_description: 'Internal server error',
      })
    }
  }

  /**
   * POST /register
   * 
   * Register a new holder user.
   * 
   * Body: { nik, nama, tanggal_lahir, email, password }
   */
  static async postRegister(req: Request, res: Response) {
    try {
      // Validate input
      const validation = validateRegistration(req.body)
      if (!validation.valid) {
        return res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: validation.errors,
        })
      }

      const { nik, nama, tanggal_lahir, email, password } = req.body

      const result = await registerHolder({
        nik,
        nama,
        tanggalLahir: tanggal_lahir,
        email,
        password,
      })

      res.status(201).json({
        success: true,
        message: 'Registration successful',
        userId: result.userId,
      })
    } catch (error: any) {
      if (error.message.includes('already registered')) {
        return res.status(409).json({
          success: false,
          error: error.message,
        })
      }

      console.error('❌ Registration error:', error.message)
      res.status(500).json({
        success: false,
        error: 'Registration failed',
        message: error.message,
      })
    }
  }
}
