import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

function shouldForceRegister(pathname: string): boolean {
  if (pathname === '/') return true
  if (pathname === '/login') return true
  if (pathname.startsWith('/dashboard')) return true
  if (pathname.startsWith('/issuer')) return true
  return false
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  if (!shouldForceRegister(pathname)) {
    return NextResponse.next()
  }

  const registerUrl = request.nextUrl.clone()
  registerUrl.pathname = '/register'
  registerUrl.search = ''
  return NextResponse.redirect(registerUrl)
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico|.*\\..*).*)'],
}
