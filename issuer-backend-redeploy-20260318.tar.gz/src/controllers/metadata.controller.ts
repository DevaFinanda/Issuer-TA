/**
 * Metadata Controller — OID4VCI Issuer Discovery
 * 
 * Implements: GET /.well-known/openid-credential-issuer
 */

import { Request, Response } from 'express'

export class MetadataController {
  private static resolveIssuerBaseUrl(): string {
    const envBaseUrl = (process.env.ISSUER_BASE_URL || '').trim()
    if (envBaseUrl) return envBaseUrl.replace(/\/$/, '')

    const envDomain = (
      process.env.ISSUER_DOMAIN ||
      process.env.DID_WEB_DOMAIN ||
      ''
    ).trim()

    const domain = envDomain
      ? envDomain.replace(/^https?:\/\//i, '').replace(/\/.*$/, '')
      : 'issuer.identia.my.id'

    return `https://${domain}`
  }

  /**
   * GET /.well-known/openid-credential-issuer
   * 
   * Returns OID4VCI issuer metadata for wallet discovery.
   * Follows OpenID4VCI Section 10.2 — Credential Issuer Metadata
   */
  static getIssuerMetadata(req: Request, res: Response) {
    const issuerBaseUrl = MetadataController.resolveIssuerBaseUrl()

    const metadata = {
      credential_issuer: issuerBaseUrl,
      authorization_endpoint: `${issuerBaseUrl}/oid4vci/authorize`,
      token_endpoint: `${issuerBaseUrl}/token`,
      credential_endpoint: `${issuerBaseUrl}/credential`,
      credential_status_endpoint: `${issuerBaseUrl}/credential/status/{credentialId}`,
      grant_types_supported: [
        'authorization_code',
        'urn:ietf:params:oauth:grant-type:pre-authorized_code',
      ],
      proof_types_supported: {
        jwt: {
          proof_signing_alg_values_supported: ['EdDSA'],
        },
      },
      credential_configurations_supported: {
        kartu_bpjs_kesehatan: {
          format: 'jwt_vc_json',
          name: 'Kartu BPJS Kesehatan',
          scope: 'kartu_bpjs_kesehatan',
          cryptographic_binding_methods_supported: ['did'],
          proof_types_supported: {
            jwt: {
              proof_signing_alg_values_supported: ['EdDSA'],
            },
          },
          credential_definition: {
            type: ['VerifiableCredential', 'KartuBPJSKesehatan'],
          },
          display: [
            {
              name: 'Kartu BPJS Kesehatan',
              locale: 'id-ID',
              description: 'Kartu identitas peserta BPJS Kesehatan berbasis Verifiable Credential.',
            },
          ],
        },
      },
      credentials_supported: [
        {
          id: 'kartu_bpjs_kesehatan',
          format: 'jwt_vc_json',
          types: ['VerifiableCredential', 'KartuBPJSKesehatan'],
          display: [
            {
              name: 'Kartu BPJS Kesehatan',
              locale: 'id-ID',
            },
          ],
        },
      ],
    }

    res.json(metadata)
  }
}
