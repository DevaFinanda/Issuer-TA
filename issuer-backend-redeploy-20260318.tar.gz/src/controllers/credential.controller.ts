/**
 * Credential Controller — OID4VCI Credential Issuance
 * 
 * Implements: POST /credential
 * 
 * The wallet calls this endpoint with a Bearer access token
 * to request the actual Verifiable Credential.
 */

import { Request, Response } from 'express'
import crypto from 'crypto'
import { findUserById } from '../services/user.service.js'
import { getCredentialStatusSummary, storeCredentialDB } from '../services/credential.service.js'
import { createSignedVC, getIssuerDID } from '../credential/vc-generator.js'
import { validateCredentialRequest, validateDid } from '../security/validation.js'
import {
  ProofVerificationError,
  verifyHolderProofJwt,
  verifyPresentedCredentialJwt,
} from '../services/proof.service.js'
import { rotateTokenNonce } from '../services/token.service.js'

export class CredentialController {
  private static resolveIssuerBaseUrl(): string {
    const envBaseUrl = (process.env.ISSUER_BASE_URL || '').trim()
    if (envBaseUrl) return envBaseUrl.replace(/\/$/, '')

    const envDomain = (
      process.env.ISSUER_DOMAIN ||
      process.env.DID_WEB_DOMAIN ||
      ''
    ).trim()

    const domain = envDomain
      ? envDomain.replace(/^https?:\/\//i, '').replace(/\/.*$/, '')
      : 'issuer.identia.my.id'

    return `https://${domain}`
  }

  /**
   * POST /credential
   * 
   * Issue a signed JWT Verifiable Credential.
   * 
   * Requires: Authorization: Bearer <access_token>
   * 
   * Body: {
   *   format: "jwt_vc_json",
   *   credential_definition: {
   *     type: ["VerifiableCredential", "IdentityCredential"]
   *   }
   * }
   * 
   * Response: {
   *   format: "jwt_vc_json",
   *   credential: "<signed_jwt>"
   * }
   */
  static async issueCredential(req: Request, res: Response) {
    try {
      // userId is set by requireBearerToken middleware
      const userId = req.userId
      if (!userId) {
        return res.status(401).json({
          error: 'invalid_token',
          error_description: 'No user associated with this token',
        })
      }

      // Validate credential request body
      const validation = validateCredentialRequest(req.body)
      if (!validation.valid) {
        return res.status(400).json({
          error: 'invalid_request',
          error_description: validation.errors.join(', '),
        })
      }

      const holderDid = req.userDid
      const cNonce = req.cNonce
      const accessToken = req.accessToken

      if (!holderDid || !cNonce || !accessToken) {
        return res.status(401).json({
          error: 'invalid_token',
          error_description: 'Access token DID/nonce context is missing',
        })
      }

      const requestDid = String(req.body?.holderDid || req.body?.holder_did || '').trim()
      if (requestDid && requestDid !== holderDid) {
        return res.status(401).json({
          error: 'invalid_proof',
          error_description: 'Requested holder DID does not match token DID',
        })
      }

      const didValidation = validateDid(holderDid)
      if (!didValidation.valid) {
        return res.status(400).json({
          error: 'invalid_request',
          error_description: didValidation.error,
        })
      }

      // SSI mandatory proof-of-possession check.
      await verifyHolderProofJwt({
        proofJwt: String(req.body?.proof?.jwt || ''),
        expectedNonce: cNonce,
        expectedDid: holderDid,
      })

      const requestFormat = (req.body?.format as string | undefined) || 'jwt_vc_json'
      const requestedTypes = req.body?.credential_definition?.type
      const normalizedTypes = Array.isArray(requestedTypes)
        ? requestedTypes
          .map((t: unknown) => String(t))
          .map((t: string) => {
            const normalized = t.trim().toLowerCase()
            if (normalized === 'identitycredential' || normalized === 'identity_credential') {
              return 'KartuBPJSKesehatan'
            }
            return t
          })
        : []
      const credentialTypes = Array.from(new Set([
        ...normalizedTypes,
        'VerifiableCredential',
        'KartuBPJSKesehatan',
      ]))

      // Get user data from database
      const user = await findUserById(userId)
      if (!user) {
        return res.status(404).json({
          error: 'invalid_request',
          error_description: 'User not found',
        })
      }

      if (!user.nik || !(user.nama || user.fullName)) {
        return res.status(400).json({
          error: 'invalid_request',
          error_description: 'Profil pengguna tidak lengkap (NIK dan nama diperlukan)',
        })
      }

      // Build KartuBPJSKesehatan credential subject bound to holder DID
      const credentialSubject = {
        id: holderDid,
        credentialName: 'Kartu BPJS Kesehatan',
        nama: user.nama || user.fullName,
        nomorNIK: user.nik,
        tanggalLahir: user.tanggalLahir
          ? user.tanggalLahir.toISOString().split('T')[0]
          : undefined,
      }

      const credentialRecordId = crypto.randomUUID()
      const issuerBaseUrl = CredentialController.resolveIssuerBaseUrl()
      const credentialStatusUrl = `${issuerBaseUrl}/credential-status/${credentialRecordId}`

      const signedJwt = await createSignedVC(
        credentialSubject,
        holderDid,
        credentialTypes,
        {
          credentialId: credentialRecordId,
          credentialStatusUrl,
        }
      )

      // Store credential in database
      const issuerDID = getIssuerDID()
      const expiryDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) // 1 year

      const credentialId = await storeCredentialDB({
        id: credentialRecordId,
        credentialJwt: signedJwt,
        format: requestFormat,
        holderDID: holderDid,
        holderName: user.nama || user.fullName,
        nik: user.nik,
        nama: user.nama || user.fullName,
        tanggalLahir: user.tanggalLahir
          ? user.tanggalLahir.toISOString().split('T')[0]
          : undefined,
        metadata: {
          credentialType: 'KartuBPJSKesehatan',
          credentialTypeDisplay: 'Kartu BPJS Kesehatan',
          credentialSubject,
        },
        issuerDID,
        issuerName: process.env.ISSUER_NAME || 'Issuer Kartu BPJS Kesehatan',
        validUntil: expiryDate,
        userId: user.id,
      })

      console.log('✅ Credential issued to:', user.nama)
      console.log('📋 Credential ID:', credentialId)

      const rotatedNonce = await rotateTokenNonce(accessToken)

      // Return credential to wallet (OID4VCI response format)
      res.json({
        format: requestFormat,
        credential: signedJwt,
        credential_id: credentialId,
        c_nonce: rotatedNonce.cNonce,
        c_nonce_expires_in: rotatedNonce.cNonceExpiresIn,
        credential_status: {
          id: credentialStatusUrl,
          type: 'SimpleCredentialStatus2026',
        },
      })
    } catch (error: any) {
      if (error instanceof ProofVerificationError) {
        return res.status(error.statusCode).json({
          error: 'invalid_proof',
          error_description: error.message,
        })
      }

      console.error('❌ Credential issuance error:', error.message)
      res.status(500).json({
        error: 'server_error',
        error_description: 'Failed to issue credential',
      })
    }
  }

  /**
   * MODE 2 (SSI-native): Holder presents existing VC, backend verifies VC cryptographically,
   * then checks claims against trusted registry before issuing new VC.
   */
  static async issueCredentialSsiNative(req: Request, res: Response) {
    try {
      const userId = req.userId
      const holderDid = req.userDid
      const cNonce = req.cNonce
      const accessToken = req.accessToken

      if (!userId || !holderDid || !cNonce || !accessToken) {
        return res.status(401).json({
          error: 'invalid_token',
          error_description: 'Access token DID/nonce context is missing',
        })
      }

      if (!req.body?.presented_vc || typeof req.body.presented_vc !== 'string') {
        return res.status(400).json({
          error: 'invalid_request',
          error_description: 'presented_vc is required in SSI-native mode',
        })
      }

      await verifyHolderProofJwt({
        proofJwt: String(req.body?.proof?.jwt || ''),
        expectedNonce: cNonce,
        expectedDid: holderDid,
      })

      const presentedPayload = await verifyPresentedCredentialJwt(req.body.presented_vc)
      const vc = (presentedPayload as Record<string, any>).vc || {}
      const credentialSubject = vc.credentialSubject || {}

      const registryNik = String(credentialSubject.nomorNIK || credentialSubject.nik || '').trim()
      const registryEmail = String(credentialSubject.email || '').trim().toLowerCase()

      // Database acts as trusted registry for claim matching only.
      const matchedUser = await findUserById(userId)
      if (!matchedUser) {
        return res.status(404).json({
          error: 'invalid_request',
          error_description: 'User registry entry not found',
        })
      }

      const nikMatches = !!registryNik && registryNik === (matchedUser.nik || '')
      const emailMatches = !!registryEmail && registryEmail === matchedUser.email.toLowerCase()

      if (!nikMatches && !emailMatches) {
        return res.status(403).json({
          error: 'access_denied',
          error_description: 'Presented VC claims do not match trusted registry',
        })
      }

      const normalizedBody = {
        ...req.body,
        holderDid,
      }
      req.body = normalizedBody

      return CredentialController.issueCredential(req, res)
    } catch (error: any) {
      if (error instanceof ProofVerificationError) {
        return res.status(error.statusCode).json({
          error: 'invalid_proof',
          error_description: error.message,
        })
      }

      return res.status(500).json({
        error: 'server_error',
        error_description: error.message || 'Failed to process SSI-native issuance',
      })
    }
  }

  static async getCredentialStatus(req: Request, res: Response) {
    try {
      const summary = await getCredentialStatusSummary(req.params.id)
      if (!summary) {
        return res.status(404).json({
          error: 'not_found',
          error_description: 'Credential status not found',
        })
      }

      return res.json({
        credential_id: summary.credentialId,
        status: summary.status,
        status_list: {
          active: summary.status === 'ACTIVE',
          suspended: summary.suspended,
          revoked: summary.revoked,
          expired: summary.expired,
        },
        valid_until: summary.validUntil,
        updated_at: summary.updatedAt,
        reason: summary.revokedReason,
      })
    } catch (error: any) {
      return res.status(500).json({
        error: 'server_error',
        error_description: error.message,
      })
    }
  }
}
