import { verifyJWT, type JWTVerified } from 'did-jwt'
import { Resolver } from 'did-resolver'
import { getResolver as getWebDidResolver } from 'web-did-resolver'
import { getResolver as getKeyDidResolver } from 'key-did-resolver'

const didResolver = new Resolver({
  ...getWebDidResolver(),
  ...getKeyDidResolver(),
}) as any

function getIssuerAudience(): string {
  const envBaseUrl = (process.env.ISSUER_BASE_URL || '').trim()
  if (envBaseUrl) return envBaseUrl.replace(/\/$/, '')

  const envDomain = (
    process.env.ISSUER_DOMAIN ||
    process.env.DID_WEB_DOMAIN ||
    ''
  ).trim()

  const domain = envDomain
    ? envDomain.replace(/^https?:\/\//i, '').replace(/\/.*$/, '')
    : 'issuer.identia.my.id'

  return `https://${domain}`
}

function safeString(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  const normalized = value.trim()
  return normalized.length > 0 ? normalized : undefined
}

export class ProofVerificationError extends Error {
  statusCode: number

  constructor(message: string, statusCode: number = 400) {
    super(message)
    this.name = 'ProofVerificationError'
    this.statusCode = statusCode
  }
}

export async function verifyHolderProofJwt(input: {
  proofJwt: string
  expectedNonce: string
  expectedDid: string
}): Promise<{
  holderDid: string
  proofPayload: JWTVerified['payload']
}> {
  const audience = getIssuerAudience()

  let verified: JWTVerified
  try {
    verified = await verifyJWT(input.proofJwt, {
      resolver: didResolver,
      audience,
    })
  } catch (error: any) {
    throw new ProofVerificationError(`Invalid proof JWT signature: ${error.message || 'verification failed'}`, 401)
  }

  const holderDid = safeString(verified.payload.iss) || safeString(verified.payload.sub)
  if (!holderDid) {
    throw new ProofVerificationError('Proof JWT must contain holder DID in iss or sub', 400)
  }

  if (holderDid !== input.expectedDid) {
    throw new ProofVerificationError('Proof DID does not match token-bound holder DID', 401)
  }

  const nonce = safeString((verified.payload as Record<string, unknown>).nonce)
  if (!nonce) {
    throw new ProofVerificationError('Proof JWT nonce is missing', 400)
  }

  if (nonce !== input.expectedNonce) {
    throw new ProofVerificationError('Proof JWT nonce mismatch', 401)
  }

  const now = Math.floor(Date.now() / 1000)
  if (typeof verified.payload.exp === 'number' && verified.payload.exp < now) {
    throw new ProofVerificationError('Proof JWT has expired', 401)
  }

  if (typeof verified.payload.nbf === 'number' && verified.payload.nbf > now + 30) {
    throw new ProofVerificationError('Proof JWT not yet valid', 401)
  }

  return {
    holderDid,
    proofPayload: verified.payload,
  }
}

export async function verifyPresentedCredentialJwt(credentialJwt: string): Promise<JWTVerified['payload']> {
  try {
    const verified = await verifyJWT(credentialJwt, {
      resolver: didResolver,
    })

    const vc = (verified.payload as Record<string, unknown>).vc
    if (!vc || typeof vc !== 'object') {
      throw new ProofVerificationError('Presented VC payload is missing vc object', 400)
    }

    return verified.payload
  } catch (error: any) {
    if (error instanceof ProofVerificationError) {
      throw error
    }

    throw new ProofVerificationError(`Presented VC signature verification failed: ${error.message || 'unknown error'}`, 401)
  }
}
