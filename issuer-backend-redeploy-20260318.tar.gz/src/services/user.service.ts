/**
 * User Service — Registration and lookup by NIK
 */

import { prisma, AuditAction } from '../lib/prisma.js'
import bcrypt from 'bcryptjs'

const BCRYPT_ROUNDS = 12

/**
 * Register a new holder user
 */
export async function registerHolder(input: {
  nik: string
  nama?: string
  tanggalLahir?: string
  email?: string
  password: string
}): Promise<{ userId: string; created: boolean }> {
  // Check if NIK already exists
  const existingNik = await prisma.user.findUnique({
    where: { nik: input.nik },
  })

  const normalizedNama = (input.nama || '').trim()
  const resolvedNama = normalizedNama || `Pemegang ${input.nik.slice(-4)}`
  const normalizedEmail = (input.email || '').trim().toLowerCase()
  const resolvedEmail = normalizedEmail || `${input.nik}@holder.identia.local`

  // Check if email already exists (including auto-generated fallback)
  const existingEmail = await prisma.user.findUnique({
    where: { email: resolvedEmail },
  })
  if (existingEmail && existingEmail.id !== existingNik?.id) {
    throw new Error('Email already registered')
  }

  // Hash password with bcrypt
  const passwordHash = await bcrypt.hash(input.password, BCRYPT_ROUNDS)

  if (existingNik) {
    const user = await prisma.user.update({
      where: { id: existingNik.id },
      data: {
        email: resolvedEmail,
        passwordHash,
        fullName: resolvedNama,
        nama: resolvedNama,
        tanggalLahir: input.tanggalLahir ? new Date(input.tanggalLahir) : null,
        isActive: true,
      },
    })

    await prisma.auditLog.create({
      data: {
        action: AuditAction.USER_UPDATED,
        entityType: 'User',
        entityId: user.id,
        actorType: 'holder',
        actorId: user.id,
        details: { nik: input.nik, nama: resolvedNama, source: 'register_sync' } as any,
      },
    })

    console.log('♻️ Holder profile synced:', input.nik, resolvedNama)
    return { userId: user.id, created: false }
  }

  // Create user
  const user = await prisma.user.create({
    data: {
      email: resolvedEmail,
      passwordHash,
      fullName: resolvedNama,
      nik: input.nik,
      nama: resolvedNama,
      tanggalLahir: input.tanggalLahir ? new Date(input.tanggalLahir) : null,
      userType: 'HOLDER',
      role: 'OPERATOR',
      isActive: true,
    },
  })

  // Audit log
  await prisma.auditLog.create({
    data: {
      action: AuditAction.USER_REGISTERED,
      entityType: 'User',
      entityId: user.id,
      actorType: 'holder',
      actorId: user.id,
      details: { nik: input.nik, nama: resolvedNama } as any,
    },
  })

  console.log('✅ Holder registered:', input.nik, resolvedNama)
  return { userId: user.id, created: true }
}

/**
 * Find user by NIK
 */
export async function findUserByNIK(nik: string) {
  return prisma.user.findUnique({
    where: { nik },
  })
}

/**
 * Find user by ID
 */
export async function findUserById(id: string) {
  return prisma.user.findUnique({
    where: { id },
  })
}

/**
 * Verify user password
 */
export async function verifyPassword(passwordHash: string, password: string): Promise<boolean> {
  return bcrypt.compare(password, passwordHash)
}

function userDidBindingKey(userId: string) {
  return `user-did-binding:${userId}`
}

function didUserBindingKey(holderDid: string) {
  return `did-user-binding:${holderDid}`
}

/**
 * Bind an authenticated user account to holder DID.
 * This keeps DID as primary SSI identity while username/password is bootstrap only.
 */
export async function bindUserDid(userId: string, holderDid: string): Promise<void> {
  const now = new Date().toISOString()

  await prisma.issuerConfig.upsert({
    where: { key: userDidBindingKey(userId) },
    update: {
      value: holderDid,
      description: `holder DID binding updated at ${now}`,
    },
    create: {
      key: userDidBindingKey(userId),
      value: holderDid,
      description: `holder DID binding created at ${now}`,
    },
  })

  await prisma.issuerConfig.upsert({
    where: { key: didUserBindingKey(holderDid) },
    update: {
      value: userId,
      description: `holder DID reverse binding updated at ${now}`,
    },
    create: {
      key: didUserBindingKey(holderDid),
      value: userId,
      description: `holder DID reverse binding created at ${now}`,
    },
  })
}

export async function getBoundDidForUser(userId: string): Promise<string | null> {
  const record = await prisma.issuerConfig.findUnique({
    where: { key: userDidBindingKey(userId) },
    select: { value: true },
  })

  return record?.value || null
}

export async function getUserIdByDid(holderDid: string): Promise<string | null> {
  const record = await prisma.issuerConfig.findUnique({
    where: { key: didUserBindingKey(holderDid) },
    select: { value: true },
  })

  return record?.value || null
}
