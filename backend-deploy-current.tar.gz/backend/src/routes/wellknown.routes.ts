/**
 * Well-Known Routes — OID4VCI Issuer Discovery
 */

import { Router, type IRouter } from 'express'
import path from 'path'
import { fileURLToPath } from 'url'
import { MetadataController } from '../controllers/metadata.controller.js'

const router: IRouter = Router()
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// GET /.well-known/did.json
router.get('/did.json', (_req, res) => {
	const didPath = path.join(__dirname, '../../public/.well-known/did.json')
	res.type('application/did+json')
	res.sendFile(didPath)
})

// GET /.well-known/openid-credential-issuer
router.get('/openid-credential-issuer', MetadataController.getIssuerMetadata)

// GET /.well-known/oauth-authorization-server
router.get('/oauth-authorization-server', MetadataController.getAuthorizationServerMetadata)

// GET /.well-known/openid-configuration
router.get('/openid-configuration', MetadataController.getOpenIdConfiguration)

export default router
